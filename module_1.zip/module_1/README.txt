Name: Dylan Breen (dbreen1)
Module Info: Module 1 Assignment: Personal Website Due on 08/31/2025 at 11:59PM EST





How to launch my webpage:

1. Copy joepimetheus folder to local server.
2. Consult requirements.txt to ensure the local environment is aligned with requirements.
3. Ensure your python is up to date.
4. ensure Flask is installed
5. run the following code in your terminal in the copied joepimetheus folder
    python run.py





Approach:
Built with resources available, commit often to track changes along the process. Once I got most of the way, used LLM resources to help with style.css, kept flair where appropriate. Additionally, since this is just a piece of a larger project, I included additional comments to help remind me what the different areas of the code actually do so I can retain as a move forward. If some of it seems obvious, it has yet to be for me. This will help.


Known Bugs and Issues: 
Style.css is a mess, will need to clean up in later version, from a webpage perspective though it works as desired. Created placeholders for pyhton files and directory structure for future state/expansion/versions. That is why they are empty.


Citations:
Consulted readings, Lecture, and Office hour recordings. Lecture Slides. ChatGPT assistance after exhausting resources. Use ChatGPT to help draft css and make adjustments.